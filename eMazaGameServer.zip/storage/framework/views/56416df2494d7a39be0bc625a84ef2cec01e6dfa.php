<!DOCTYPE html>
<html lang="en" class="no-js">
<head>

    <?php echo $__env->make('base.include-seo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('base.include-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="is-boxed has-animations">
    <div class="body-wrap">

    <?php echo $__env->make('landing.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <?php echo $__env->make('landing.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <?php echo $__env->make('landing.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

    <script src="<?php echo e(asset('template/dist/js/main.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\User\curso web & mobile\eMazaGameServer\resources\views/landing.blade.php ENDPATH**/ ?>