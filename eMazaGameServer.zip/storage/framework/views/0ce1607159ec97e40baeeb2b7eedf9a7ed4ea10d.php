
<header class="site-header">

    <div class="container">
        <div class="site-header-inner">
            <div class="brand header-brand">
                <h1 class="m-0">
                    <a href="#">
                        <img
                            class="header-logo-image"
                            src="<?php echo e(asset('contents/eMazaGame.png')); ?>"
                            alt="Logo"
                             style="width: 80px; height: 80px"
                        >

                    </a>
                </h1>
            </div>
        </div>
    </div>
</header>

<?php /**PATH C:\Users\User\curso web & mobile\eMazaGameServer\resources\views/landing/header.blade.php ENDPATH**/ ?>